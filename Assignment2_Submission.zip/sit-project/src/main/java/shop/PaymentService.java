package shop;

public class PaymentService {
    public boolean processPayment(double amount) {
        return amount > 0;
    }
}
